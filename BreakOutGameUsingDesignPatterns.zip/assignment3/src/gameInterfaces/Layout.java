package gameInterfaces;

/**
 * Layout interface
 * Used by the gameDisplay package.
 * Implemented by LayoutManagers.
 * 
 */

public interface Layout {
	public final static int NULL_LAYOUT = 0;
	public final static int GROUP_LAYOUT = 3;
	public final static int FLOW_LAYOUT = 1;
	public final static int BORDER_LAYOUT = 2;
}
