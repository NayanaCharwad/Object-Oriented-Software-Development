package gameInterfaces;


/**
 * Loadable interface
 * Used by the gameEngine package.
 * Implemented by TimerObservable.
 * 
 */

public interface Loadable {
	
	//load object state
		public void loadMe();
		
		public void loadMe(int layoutIndex);

}
