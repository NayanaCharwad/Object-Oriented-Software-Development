package gameInterfaces;

/**
 * Savable Interface
 * Used by the gameEngine package.
 * Implemented by TimerObservable
 * 
 */

public interface Savable {

	//save object state
	public void saveMe();
	
	public int saveMe(String layoutName);

}
