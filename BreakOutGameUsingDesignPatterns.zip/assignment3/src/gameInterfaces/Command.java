package gameInterfaces;

/**
 * Command interface
 * Used by the gameCommand package.
 * Implemented by Commands.
 * 	(Load,Pause,Replay,Resume,Save,Start,Undo)
 */


public interface Command {
	
	public void execute();
	
}