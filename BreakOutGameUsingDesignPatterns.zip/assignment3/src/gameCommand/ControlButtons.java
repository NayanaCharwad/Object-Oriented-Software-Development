
package gameCommand;

import gameDisplay.LayoutManager;
import gameDisplay.DisplayClock;
import gameDisplay.GameBoard;
import gameDisplay.MenuBoard;
import gameEngine.TimerObservable;
import gameInit.Constants;
import gameInit.GameDriver;
import gameInterfaces.Command;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observer;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 * 
 * @author
 *
 */

public class ControlButtons extends JPanel implements Constants {

	private Command theCommand;
	private int gameState;
	private GameDriver gameDriver;
	private GameBoard game;
	private DisplayClock clock;
	private TimerObservable timerObs;
	private boolean isPaused;
	private boolean isStart;
	private int layoutIndex;
	private LayoutManager layoutManager;
	private GameDriver driver;

	public JButton st_but = new JButton("Start");
	public JButton st_pse = new JButton("Pause");
	public JButton st_undo = new JButton("Undo");
	public JButton st_replay = new JButton("Replay");
	public JButton st_layout = new JButton("Change" + "\n" + "Layout");
	public JButton st_save = new JButton("Save");
	public JButton st_load = new JButton("Load");

	public ControlButtons(final GameBoard game, final DisplayClock clock, final GameDriver driver, final MenuBoard menu) {

		this.driver = driver;
		layoutManager = new LayoutManager(this, game, driver, menu, clock);
		timerObs = new TimerObservable(this);

		layoutIndex = 1;
		setStart(false);
		setPaused(false);
		layoutManager.changeLayout(layoutIndex, timerObs);
		
		st_but.setBackground(Color.black);
		st_but.setForeground(Color.white);
		st_but.setFont(new Font("AR DESTINE", Font.PLAIN, 18));
		
		st_pse.setBackground(Color.black);
		st_pse.setForeground(Color.white);
		st_pse.setFont(new Font("AR DESTINE", Font.PLAIN, 18));
		
		st_layout.setBackground(Color.black);
		st_layout.setForeground(Color.white);
		st_layout.setFont(new Font("AR DESTINE", Font.PLAIN, 18));
		
		
		st_load.setBackground(Color.black);
		st_load.setForeground(Color.white);
		st_load.setFont(new Font("AR DESTINE", Font.PLAIN, 18));
		
		
		st_replay.setBackground(Color.black);
		st_replay.setForeground(Color.white);
		st_replay.setFont(new Font("AR DESTINE", Font.PLAIN, 18));
		
		st_save.setBackground(Color.black);
		st_save.setForeground(Color.white);
		st_save.setFont(new Font("AR DESTINE", Font.PLAIN, 18));
		
		st_undo.setBackground(Color.black);
		st_undo.setForeground(Color.white);
		st_undo.setFont(new Font("AR DESTINE", Font.PLAIN, 18));
		
		menu.add(this);
		st_pse.setEnabled(false);
		st_undo.setEnabled(false);
		st_replay.setEnabled(false);
		st_save.setEnabled(false);

		st_but.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				st_load.setEnabled(true);
				st_pse.setEnabled(true);
				st_undo.setEnabled(true);
				st_replay.setEnabled(true);
				st_save.setEnabled(true);
				game.requestFocusInWindow();

				if (st_but.getText().equals("Restart")) {
					st_but.setText("Start");
					st_pse.setText("Pause");
					timerObs.getTimer().stop();
					timerObs = new TimerObservable(ControlButtons.this);
					setTimerObs(timerObs);
					timerObs.addObserver((Observer) game);
					timerObs.addObserver((Observer) clock);
				}

				else if (st_but.getText().equals("Start")) {
					StartCommand startCmd;
					startCmd = new StartCommand(timerObs);
					timerObs.addObserver((Observer) game);
					timerObs.addObserver((Observer) clock);
					setTheCommand(startCmd);
					press();
					st_but.setText("Restart");
				}
			}

		});

		st_pse.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent ae) {
				st_but.setEnabled(true);
				st_replay.setEnabled(true);
				
				if (timerObs.getComputeCoordinatesObj().getGameFlag() == 2) {
					st_but.setEnabled(true);
					st_pse.setEnabled(false);
					st_undo.setEnabled(false);
					st_replay.setEnabled(false);
					timerObs.getTimer().stop();
					timerObs.deleteObservers();
				}

				if (st_pse.getText().equals("Pause")) {
					PauseCommand pauseCmd;
					pauseCmd = new PauseCommand(timerObs);
					timerObs.deleteObserver((Observer) game);
					timerObs.deleteObserver((Observer) clock);
					setTheCommand(pauseCmd);
					press();
					st_pse.setText("Resume");
				} else {
					ResumeCommand resumeCmd;
					resumeCmd = new ResumeCommand(timerObs);
					timerObs.addObserver((Observer) game);
					timerObs.addObserver(clock);
					setTheCommand(resumeCmd);
					press();
					game.requestFocusInWindow();
					st_pse.setText("Pause");
				}
			}
		});

		st_undo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				st_but.setEnabled(true);
				st_pse.setEnabled(true);
				st_undo.setEnabled(true);
				st_replay.setEnabled(true);
				st_pse.setText("Resume");
				isStart = false;
				UndoCommand undoCmd;
				undoCmd = new UndoCommand(timerObs);
				setTheCommand(undoCmd);
				press();
			}
		});

		st_replay.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				st_but.setEnabled(true);
				st_pse.setText("Resume");
				st_pse.setEnabled(true);
				st_undo.setEnabled(false);
				st_replay.setEnabled(false);
				isStart = false;
				timerObs.addObserver((Observer) game);
				timerObs.addObserver((Observer) clock);
				ReplayCommand replyCmd;
				replyCmd = new ReplayCommand(timerObs);
				setTheCommand(replyCmd);
				press();
				st_undo.setEnabled(true);
				st_replay.setEnabled(true);

			}
		});
		st_layout.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {

				layoutIndex = (layoutIndex % 2) + 1;
				layoutManager.changeLayout(layoutIndex, timerObs);
				PauseCommand pauseCmd;
				pauseCmd = new PauseCommand(timerObs);
				setTheCommand(pauseCmd);
				press();
				game.repaint();
				ResumeCommand resumeCmd;
				resumeCmd = new ResumeCommand(timerObs);
				setTheCommand(resumeCmd);
				press();

				game.requestFocusInWindow();
			}
		});

		st_save.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				st_but.setEnabled(false);
				st_pse.setEnabled(true);
				st_undo.setEnabled(false);
				st_replay.setEnabled(false);
				st_load.setEnabled(true);
				st_layout.setEnabled(true);
				st_pse.setText("Resume");
				isStart = false;
				timerObs.getTimer().stop();
				SaveCommand saveCmd;   
				saveCmd = new SaveCommand(timerObs);
				setTheCommand(saveCmd);
				game.requestFocusInWindow();
				press();
			}
		});
		
		st_load.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				st_but.setEnabled(true);
				st_pse.setEnabled(false);
				st_undo.setEnabled(false);
				st_replay.setEnabled(true);
				st_layout.setEnabled(true);
				//st_pse.setText("Resume");
				st_but.setText("Start");
				isStart = false;
				getTimerObs().getTimer().stop();
				LoadCommand loadCmd;   
				loadCmd = new LoadCommand(timerObs);
				setTheCommand(loadCmd);
				game.requestFocusInWindow();
				press();		
			}
		});

		setBackground(Color.black);
	}

	public LayoutManager getLayoutManager() {
		return layoutManager;
	}

	public void setLayoutManager(LayoutManager layoutManager) {
		this.layoutManager = layoutManager;
	}

	public int getLayoutIndex() {
		return layoutIndex;
	}

	public void setLayoutIndex(int layoutIndex) {
		this.layoutIndex = layoutIndex;
	}

	public boolean isPaused() {
		return isPaused;
	}

	public void setPaused(boolean isPaused) {
		this.isPaused = isPaused;
	}

	public boolean isStart() {
		return isStart;
	}

	public void setStart(boolean isStart) {
		this.isStart = isStart;
	}

	public TimerObservable getTimerObs() {
		return timerObs;
	}

	public void setTimerObs(TimerObservable timerObs) {
		this.timerObs = timerObs;
	}

	public GameBoard getGame() {
		return game;
	}

	public void setGame(GameBoard game) {
		this.game = game;
	}

	public DisplayClock getClock() {
		return clock;
	}

	public void setClock(DisplayClock clock) {
		this.clock = clock;
	}

	public void press() {
		theCommand.execute();
	}

	public void setGameDriver(GameDriver gameDriver) {
		this.gameDriver = gameDriver;
	}

	public GameDriver getGameDriver() {
		return gameDriver;
	}

	public int getGameState() {
		return gameState;
	}

	public void setGameState(int gameState) {
		this.gameState = gameState;
	}

	public Command getTheCommand() {
		return theCommand;
	}

	public void setTheCommand(Command theCommand) {
		this.theCommand = theCommand;
	}
}

