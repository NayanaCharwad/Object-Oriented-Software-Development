package gameInit;

import gameDisplay.DisplayClock;
import gameDisplay.GameBoard;
import gameDisplay.MenuBoard;
import gameEngine.TimerObservable;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EtchedBorder;

/**
 * Game Driver is the frame that contains all of the display components of
 * breakout. It initializes and adds the panels and starts the game engine.
 * 
 * public methods: main() - intializes an object of the GameDriver class
 * 
 */

public class GameDriver extends JFrame implements Constants {

	private GameBoard game;
	private MenuBoard menu;
	private DisplayClock clock;
	private JPanel clocksubpanel;

	TimerObservable timerObs;

	public JPanel getClocksubpanel() {
		return clocksubpanel;
	}

	public void setClocksubpanel(JPanel clocksubpanel) {
		this.clocksubpanel = clocksubpanel;
	}

	public GameDriver() {
		setBackground(Color.black);

		clocksubpanel = new JPanel();
		clock = new DisplayClock(this);
		game = new GameBoard();
		menu = new MenuBoard(game, this, clock);
		initUI(game, menu);
	}

	/*
	 * adds the MenuBoard, GameBoard, and clock in their appropriate positions.
	 */
	private void initUI(GameBoard game, MenuBoard menu) {

		// setLayout(new BorderLayout());
		// // setLayout(new GridBagLayout());
		// // GridBagConstraints constraint = new GridBagConstraints();
		//
		// // constraint.fill = GridBagConstraints.HORIZONTAL;
		// // constraint.weightx = 1.5;
		// // constraint.ipady = GAME_HEIGHT;
		// // constraint.ipadx = GAME_WIDTH;
		// // constraint.gridx = 0;
		// // constraint.gridy = 0;

		add(game);

		// constraint.gridx = 0;
		// constraint.gridy = 1;
		// // constraint.ipady = 200;
		// // constraint.ipadx = GAME_WIDTH;
		// constraint.anchor = GridBagConstraints.PAGE_END;

		add(menu, BorderLayout.SOUTH);
		add(clocksubpanel, BorderLayout.NORTH);
		clocksubpanel.setBackground(Color.black);

//		clocksubpanel.setBorder(BorderFactory.createEtchedBorder(
//				EtchedBorder.RAISED, Color.WHITE, Color.DARK_GRAY));
//
//		menu.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED,
//				Color.WHITE, Color.DARK_GRAY));
		// clocksubpanel.setB
		clocksubpanel.add(clock);

		pack();
		setTitle("Breakout");
		setSize(WIN_WIDTH, WIN_HEIGHT);
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

	}

	public static void main(String[] args) {

		// try {
		// UIManager.setLookAndFeel("com.birosoft.liquid.LiquidLookAndFeel");
		// } catch (ClassNotFoundException e) {
		// e.printStackTrace();
		// } catch (InstantiationException e) {
		// e.printStackTrace();
		// } catch (IllegalAccessException e) {
		// e.printStackTrace();
		// } catch (UnsupportedLookAndFeelException e) {
		// e.printStackTrace();
		// }
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				GameDriver gameDriver = new GameDriver();
				gameDriver.setVisible(true);
				// gameDriver.getControlButtons().setGameDriver(gameDriver);
				// gameDriver.getControlButtons().setClock(gameDriver.getDisplayClock());
				// gameDriver.getControlButtons().setGame(gameDriver.getGameBoard());
				// gameDriver.getControlButtons().setTimerObs(gameDriver.getTimerObs());
				//
			}
		});
	}

	// ///////////////////////////////////Getters and
	// Setters//////////////////////////////////////////

	public TimerObservable getTimerObs() {
		return timerObs;
	}

	public void setTimerObs(TimerObservable timerObs) {
		this.timerObs = timerObs;
	}

	public GameBoard getGameBoard() {
		return game;
	}

	public void setGame(GameBoard game) {
		this.game = game;
	}

	// public void setClock(DisplayClock clock) {
	// this.clock = clock;
	// }

	public MenuBoard getMenuBoard() {
		return menu;
	}
	// public ControlButtons getControlButtons()
	// {
	// return controlButtons;
	// }
	// public DisplayClock getDisplayClock()
	// {
	// return clock;
	// }
}
