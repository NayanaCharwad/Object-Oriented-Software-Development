package gameInit;

/**
 * Constants for setting the Frame (WIN) and Game panel dimensions.
 * 
 */

public interface Constants {
	int WIN_WIDTH = 670;
	int WIN_HEIGHT = 750;
	int GAME_WIDTH = 620;
	int GAME_HEIGHT = 650;
	int BRICK_ROWS = 5;
	int BRICK_COLUMNS = 5;
	int TOTAL_BRICKS = BRICK_ROWS * BRICK_COLUMNS;
}
