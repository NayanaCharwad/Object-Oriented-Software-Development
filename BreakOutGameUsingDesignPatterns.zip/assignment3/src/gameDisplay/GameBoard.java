package gameDisplay;

import gameEngine.Ball;
import gameEngine.Brick;
import gameEngine.Paddle;
import gameEngine.StoreDimensions;
import gameInit.Boundaries;
import gameInit.Constants;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * 
 * @author
 *
 */

public class GameBoard extends JPanel implements Constants, Observer {

	private Image image;
	private String message;
	private Ball ball;
	private Paddle paddle;
	private Brick[] bricks;
	private int gameFlag;
	protected String bgPath = "breakout_bg1.png";
	protected String bgPath2 = "breakout_bg2.jpg";
	private JLabel background;
	private ImageIcon myImageIcon;
	private boolean bgImage = true;

	public boolean isBgImage() {
		return bgImage;
	}

	public void setBgImage(boolean bgImage) {
		this.bgImage = bgImage;
	}

	private StoreDimensions storeDimesions;

	public Image getImage() {
		return image;
	}

	public void setIi(Image image) {
		this.image = image;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Ball getBall() {
		return ball;
	}

	public void setBall(Ball ball) {
		this.ball = ball;
	}

	public Paddle getPaddle() {
		return paddle;
	}

	public void setPaddle(Paddle paddle) {
		this.paddle = paddle;
	}

	public Brick[] getBricks() {
		return bricks;
	}

	public void setBricks(Brick[] bricks) {
		this.bricks = bricks;
	}

	public int getGameFlag() {
		return gameFlag;
	}

	public void setGameFlag(int gameFlag) {
		this.gameFlag = gameFlag;
	}

	public GameBoard() {
		addKeyListener(new TAdapter());
//		setFocusable(true);
		setDoubleBuffered(true);
		setVisible(true);
		setGameFlag(0);
		
		setBackground(Color.black);
		setSize(GAME_WIDTH, GAME_HEIGHT);
		
		myImageIcon = new ImageIcon(getClass().getClassLoader().getResource(bgImage?bgPath:bgPath2));
		
		Image backgroundImage = myImageIcon.getImage();
		Image scaledBackgroundImage = backgroundImage.getScaledInstance(this.getWidth(),this.getHeight(),Image.SCALE_SMOOTH);
		background = new JLabel();
		myImageIcon.setImage(scaledBackgroundImage);
		background.setIcon(myImageIcon);
		add(background);
		
		
		
	}

	private class TAdapter extends KeyAdapter {

		@Override
		public void keyReleased(KeyEvent e) {
			paddle.keyReleased(e);
		}

		@Override
		public void keyPressed(KeyEvent e) {
			paddle.keyPressed(e);
		}
	}

	public void paint(Graphics g) {
		super.paint(g);
		myImageIcon = new ImageIcon(getClass().getClassLoader().getResource(bgImage?bgPath:bgPath2));
		
		if (this.getGameFlag() == 1) {
			g.drawImage(ball.getImage(), ball.getX(), ball.getY(),
					ball.getWidth(), ball.getHeight(), this);
			g.drawImage(paddle.getImage(), paddle.getX(), paddle.getY(),
					paddle.getWidth(), paddle.getHeight(), this);

			for (int i = 0; i < this.bricks.length; i++) {
				if (!bricks[i].isDestroyed()) {
					g.drawImage(bricks[i].getImage(), bricks[i].getX(),
							bricks[i].getY(), bricks[i].getWidth(),
							bricks[i].getHeight(), this);
				}
			}
		} else {
			Font font = new Font("Berlin Sans FB Demi", Font.BOLD, 60);
			FontMetrics metr = this.getFontMetrics(font);

			if (this.getGameFlag() == 0) {
				setMessage("Start Game");
			} else if (!this.getMessage().equalsIgnoreCase("Victory")
					&& this.getGameFlag() == 2) {
				setMessage("Game Over");
			}
			g.setColor(Color.blue);
			g.setColor(Color.WHITE);
			g.setFont(font);
			g.drawString(
					message,
					(Boundaries.WIDTH - metr.stringWidth(this.getMessage())) / 2,
					Boundaries.WIDTH / 2);
		}
		Toolkit.getDefaultToolkit().sync();
		g.dispose();
	}

	public JLabel getLBackground() {
		return background;
	}

	public void setLBackground(JLabel background) {
		this.background = background;
	}

	public ImageIcon getMyImageIcon() {
		return myImageIcon;
	}

	public void setMyImageIcon(ImageIcon myImageIcon) {
		this.myImageIcon = myImageIcon;
	}

	public void unPackShapeList(ArrayList<Object> objList) {

		for (Object obj : objList) {
			if (obj instanceof Number) {
				int flag = ((Number) obj).intValue();
				setGameFlag(flag);
			}

			else if (obj instanceof Ball) {
				setBall((Ball) obj);
			} else if (obj instanceof Brick[]) {
				setBricks((Brick[]) obj);
			} else if (obj instanceof Paddle) {
				setPaddle((Paddle) obj);
			}
		}

	}

	@Override
	public void update(Observable o, Object objList) {
		unPackShapeList((ArrayList<Object>) objList);
		repaint();
	}
}
