package gameDisplay;

/**
 * LayoutManager
 * Houses the details of each ControlButtons Layout.
 * Acts on ControlButtons and the game engine.
 * 
 * public methods:
 * void changeLayout(int) - switches layout of the game to predetermined scheme.
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.BorderFactory;
import javax.swing.GroupLayout;
import javax.swing.JPanel;
import javax.swing.border.EtchedBorder;

import gameCommand.ControlButtons;
import gameEngine.TimerObservable;
import gameInit.GameDriver;
import gameInterfaces.Layout;

public class LayoutManager implements Layout {

	private GroupLayout grouplayout;
	private ControlButtons buttons;

	JPanel subpanelS, subpanelN;
	GroupLayout groupLayout;
	FlowLayout flowLayout;
	BorderLayout borderLayout;
	GameBoard game;
	GameDriver driver;
	MenuBoard menu;
	DisplayClock clock;

	public LayoutManager(ControlButtons buttons, GameBoard game,
			GameDriver driver, MenuBoard menu, DisplayClock clock) {
		this.clock = clock;
		this.menu = menu;
		this.driver = driver;
		this.game = game;
		this.buttons = buttons;
		borderLayout = new BorderLayout();
		flowLayout = new FlowLayout();
	}

	/*
	 * Switches game layout to the layout matching the given int index.
	 * GROUP_LAYOUT, FLOW_LAYOUT, and BORDER_LAYOUT set the indices in the
	 * Layout interface.
	 */
	public void changeLayout(int layoutIndex, TimerObservable timerObs) {
		buttons.removeAll();
		buttons.invalidate();

		switch (layoutIndex) {

		case FLOW_LAYOUT:
			// When changing the layout of ControlButtons, buttons removed, need
			// to be re-added.
			buttons.setLayout(flowLayout);

			buttons.add(buttons.st_but);
			buttons.add(buttons.st_pse);
			buttons.add(buttons.st_undo);
			buttons.add(buttons.st_replay);
			buttons.add(buttons.st_layout);
			buttons.add(buttons.st_save);
			buttons.add(buttons.st_load);

			// Changes presentation of game objects.
			timerObs.getComputeCoordinatesObj().getBall()
					.changeImage("fire_ball.png");
			timerObs.getComputeCoordinatesObj().getPaddle()
					.changeImage("laser-red.png");
			for (int i = 0; i < timerObs.getComputeCoordinatesObj().getBricks().length; i++)
				timerObs.getComputeCoordinatesObj().getBricks()[i]
						.changeImage("blue.png");
			
			game.setBackground(Color.black);
			driver.getClocksubpanel().setBackground(Color.black);
			menu.setBackground(Color.black);
			game.setBgImage(true);
			game.getLBackground().setIcon(game.getMyImageIcon());

			buttons.st_undo.setBackground(Color.black);
			buttons.st_undo.setForeground(Color.white);

			buttons.st_but.setBackground(Color.black);
			buttons.st_but.setForeground(Color.white);

			buttons.st_layout.setBackground(Color.black);
			buttons.st_layout.setForeground(Color.white);

			buttons.st_load.setBackground(Color.black);
			buttons.st_load.setForeground(Color.white);

			buttons.st_pse.setBackground(Color.black);
			buttons.st_pse.setForeground(Color.white);

			buttons.st_replay.setBackground(Color.black);
			buttons.st_replay.setForeground(Color.white);

			buttons.st_save.setBackground(Color.black);
			buttons.st_save.setForeground(Color.white);
			
			clock.getTime().setForeground(Color.white);
			clock.setBackground(Color.black);
			
			break;

		case BORDER_LAYOUT:
			// Re-adds buttons in pre-fixed subpanels for Border Layout.

			subpanelS = new JPanel();
			subpanelN = new JPanel();

			subpanelN.setLayout(new GridLayout(0, 2));
			subpanelS.setLayout(new GridLayout(0, 2));
			buttons.setLayout(borderLayout);

			subpanelS.add(buttons.st_undo);
			subpanelS.add(buttons.st_replay);
			subpanelN.add(buttons.st_save);
			subpanelN.add(buttons.st_load);

			buttons.add(subpanelS, BorderLayout.SOUTH);
			buttons.add(buttons.st_layout, BorderLayout.CENTER);
			buttons.add(subpanelN, BorderLayout.NORTH);
			buttons.add(buttons.st_but, BorderLayout.WEST);
			buttons.add(buttons.st_pse, BorderLayout.EAST);

			// Changes presentation of game objects.
			timerObs.getComputeCoordinatesObj().getBall()
					.changeImage("water-ball.png");
			timerObs.getComputeCoordinatesObj().getPaddle()
					.changeImage("laser-yellow.png");
			for (int i = 0; i < timerObs.getComputeCoordinatesObj().getBricks().length; i++)
				timerObs.getComputeCoordinatesObj().getBricks()[i]
						.changeImage("green.png");

			game.setBackground(Color.white);
			driver.getClocksubpanel().setBackground(Color.white);
			menu.setBackground(Color.white);
			game.setBgImage(false);
			game.getLBackground().setIcon(game.getMyImageIcon());
			buttons.st_undo.setBackground(Color.white);
			buttons.st_undo.setForeground(Color.black);

			buttons.st_but.setBackground(Color.white);
			buttons.st_but.setForeground(Color.black);

			buttons.st_layout.setBackground(Color.white);
			buttons.st_layout.setForeground(Color.black);

			buttons.st_load.setBackground(Color.white);
			buttons.st_load.setForeground(Color.black);

			buttons.st_pse.setBackground(Color.white);
			buttons.st_pse.setForeground(Color.black);

			buttons.st_replay.setBackground(Color.white);
			buttons.st_replay.setForeground(Color.black);

			buttons.st_save.setBackground(Color.white);
			buttons.st_save.setForeground(Color.black);
			
			clock.getTime().setForeground(Color.black);
			clock.setBackground(Color.white);

			break;
		}
		buttons.revalidate();
		buttons.repaint();
		game.repaint();
	}
}
