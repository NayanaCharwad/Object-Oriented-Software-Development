package gameDisplay;

import gameInit.GameDriver;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;

/**
 * 
 * @author
 *
 */


public class DisplayClock extends JPanel implements Observer {
	
	private JLabel time = new JLabel("00:00");
	
	public JLabel getTime() {
		return time;
	}

	public void setTime(JLabel time) {
		this.time = time;
	}

	public DisplayClock(GameDriver driver) {
		FlowLayout layout = new FlowLayout();
		this.setLayout(layout);
		this.add(time);
		driver.add(this);
		this.setVisible(true);
		time.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		time.setForeground(Color.white);
//		time.setBorder(new EtchedBorder());
		setBackground(Color.black);
	}

	@Override
	public void update(Observable o, Object objList) {
		for (Object obj : (ArrayList<Object>) objList) {
			if (obj instanceof Number && (Integer) obj == 2)
				time.setText("00:00");
			else if (obj instanceof String) {
				time.setText(obj.toString());
			}
		}
	}
}
