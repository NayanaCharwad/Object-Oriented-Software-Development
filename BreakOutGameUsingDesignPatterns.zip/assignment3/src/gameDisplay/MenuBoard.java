package gameDisplay;

import gameCommand.ControlButtons;
import gameInit.Constants;
import gameInit.GameDriver;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JPanel;

/**
 * 
 * Panel for menu board
 *
 */
public class MenuBoard extends JPanel implements Constants {

	private ControlButtons controlButtons;


	public MenuBoard(GameBoard game, GameDriver driver, DisplayClock clock) {
		
		controlButtons = new ControlButtons(game, clock, driver, this);
		
		add(controlButtons);
		
		add(clock);

		setBackground(Color.black);
		setBounds(0, 650, WIN_WIDTH, 200);
		driver.add(this);
		setVisible(true);
		setSize(WIN_WIDTH, 200);
	}


	public ControlButtons getControlButtons() {
		return controlButtons;
	}


	public void setControlButtons(ControlButtons controlButtons) {
		this.controlButtons = controlButtons;
	}

}
