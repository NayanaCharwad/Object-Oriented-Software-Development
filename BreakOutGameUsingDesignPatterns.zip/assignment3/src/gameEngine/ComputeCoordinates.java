package gameEngine;


import gameInit.Boundaries;
import gameInit.Constants;

import java.awt.Point;
import java.io.Serializable;
import java.util.ArrayList;

/**
 * 
 * 
 * public methods:
 * void initBricks() - Initialize the bricks in a regular rectangular coordinate grid.
 * ArrayList getUndoObjects() - Produces a list containing objects needed to undo.
 * ArrayList getListShapeObjects() - Produces a list containing objects needed to replay.
 * ArrayList getBrickFlags() - Produces a list containing visibility booleans of bricks.
 * StoreDimension gameData() - Produces and fills out a new StoreDimensions object.
 * void saveDimensions(GameDimensions) - Updates the game engine with values from the given StoreDimensions object.
 * void performGameMovement() - Performs movement actions and resolves them in checkCollision().
 * void refresh()/restart()/reset() - These three methods turn the millisecond timer into a standard digital clock timer.
 * String updateDisplayClock() - Calculates minutes and seconds and produces a string for display.
 * void CheckCollision() -  Checks for intersections of game objects, and changes the ball's direction accordingly (or ends the game).
 * 
 *
 */

public class ComputeCoordinates implements Constants {
	private Ball ball = new Ball();
	private Paddle paddle = new Paddle();
	private Brick[] bricks;
	private int gameFlag;
	private int currentSecond, currentMinute;
    private String timeForDisplayClock = "00:00";
    int timerTracker=0;
    boolean gameInitFlag = false;
    int layoutFlag;
	


	public ComputeCoordinates() {
		
		this.ball = new Ball();
		this.paddle = new Paddle();
		this.bricks = new Brick[Constants.TOTAL_BRICKS];
		this.setGameFlag(1);
		initBricks();
	}

	/*
	 * Initialize the bricks in a regular rectangular coordinate grid.
	 */
    public void initBricks() {

        int k = 0;
        for (int i = 0; i < Constants.BRICK_ROWS  ; i++) {
            for (int j = 0; j < Constants.BRICK_COLUMNS; j++) {
                bricks[k] = new Brick(j * 70 + 160, i * 20 + 40);
                k++;
            }
        }
    }
       
    /*
     * Produces a list containing data needed to undo.
     */
    public ArrayList<Object> getUndoObjects() {
    	ArrayList<Object> listObjects = new ArrayList<Object>();
		listObjects.add(this.getGameFlag());
		listObjects.add(this.timeForDisplayClock);
		return listObjects;
    }
	
    /*
     * Produces a list containing data needed to replay.
     */
	public ArrayList<Object> getListShapeObjects() {
		ArrayList<Object> listObjects = new ArrayList<Object>();
		listObjects.add(this.getGameFlag());
		listObjects.add(this.getBall());
		listObjects.add(this.getBricks());
		listObjects.add(this.getPaddle());
		listObjects.add(this.timeForDisplayClock);
		return listObjects;
	}
	
	/*
	 * Produces a list containing visibility booleans of bricks.
	 */
	public ArrayList<Boolean> getBrickFlags() {
		ArrayList<Boolean> brickFlags = new ArrayList<Boolean>();
		for (int i=0;i<TOTAL_BRICKS;i++){
			brickFlags.add(i,this.bricks[i].isDestroyed());
		}
		return brickFlags;
	}
	
	/*
	 * Produces and fills out a new StoreDimensions object.
	 */
	public StoreDimensions gameData() {
		StoreDimensions obj = new StoreDimensions(
				this.getBall().getX(),
				this.getBall().getY(),
				this.getPaddle().getX(),
				this.getPaddle().getY(	),
				this.getGameFlag(),
				this.getTimeForDisplayClock(),
				this.getBrickFlags(),
				this.layoutFlag);
		return obj;
	}
	
	
	/*
	 * Updates the game engine with values from the given StoreDimensions object.
	 */
	public void saveDimensions(StoreDimensions obj)
	{
		getBall().setX(obj.getBallX());
		getBall().setY(obj.getBallY());
		getPaddle().setY(obj.getPaddleY());
		getPaddle().setX(obj.getPaddleX());
		setGameFlag(obj.getGameFlag());
		setTimeForDisplayClock(obj.getSetTimeForDisplayClock());
		ArrayList<Boolean> getBrickFlags = obj.getIsBrickDestroyed();
		this.setLayoutFlag(obj.layoutFlag);
		for (int i=0;i<TOTAL_BRICKS;i++){
			this.bricks[i].setDestroyed(getBrickFlags.get(i));
		}
	}
	
	/*
	 * Performs movement actions and resolves them in checkCollision().
	 */
	public void performGameMovement() {	
		if (this.getGameFlag()==1){			
	        this.ball.move();
	        this.paddle.move();
	        checkCollision();
		}
	}
	
	
	/*
	 * These three methods turn the millisecond timer into a standard digital clock timer.
	 */
	public void refresh() {
        currentMinute++;
        currentSecond = 0;
	}
	public void start() {
        currentMinute++;
	}
	public void reset() {
        currentMinute = -1;
        currentSecond = 0;
        timeForDisplayClock = "00:00";

	}          

	/*
	 * Calculates minutes and seconds and produces a string for display.
	 */
	public String updateDisplayClock() {
		
		currentSecond = Integer.parseInt(timeForDisplayClock.substring(3, 5));
		currentMinute = Integer.parseInt(timeForDisplayClock.substring(0, 2));
		
		timerTracker++;
		if (timerTracker >= 100) {
			if (currentSecond == 60) {
				refresh();
			}
			currentSecond++;
			timeForDisplayClock = String.format("%02d:%02d", currentMinute,currentSecond);
			timerTracker = 0;
		}
		return timeForDisplayClock;
	}
	
	/*
	 * Checks for intersections of game objects, and changes the ball's direction accordingly (or ends the game).
	 */
	public void checkCollision() {	
		//Game Over ball dropping check
		if (ball.getRect().getMaxY() > Boundaries.BOTTOM) {
            System.out.println("Ball dropped off.. Game Over");
            setGameFlag(2);
        }
		
		//Intersection with paddle
        if ((ball.getRect()).intersects(paddle.getRect())) {
            int paddleLPos = (int) paddle.getRect().getMinX();
            int ballLPos = (int) ball.getRect().getMinX();
            int first = paddleLPos + 8;
            int second = paddleLPos + 16;
            int third = paddleLPos + 24;
            int fourth = paddleLPos + 32;

            if (ballLPos < first) {
                ball.setXDir(-1);
                ball.setYDir(-1);
            }

            if (ballLPos >= first && ballLPos < second) {
                ball.setXDir(-1);
                ball.setYDir(-1 * ball.getYDir());
            }

            if (ballLPos >= second && ballLPos < third) {
                ball.setXDir(0);
                ball.setYDir(-1);
            }

            if (ballLPos >= third && ballLPos < fourth) {
                ball.setXDir(1);
                ball.setYDir(-1 * ball.getYDir());
            }

            if (ballLPos > fourth) {
                ball.setXDir(1);
                ball.setYDir(-1);
            }
        }
        
        //Intersections with bricks
        for (int i = 0; i < this.bricks.length ; i++) {
            if ((ball.getRect()).intersects(bricks[i].getRect())) {

                int ballLeft = (int) ball.getRect().getMinX();
                int ballHeight = (int) ball.getRect().getHeight();
                int ballWidth = (int) ball.getRect().getWidth();
                int ballTop = (int) ball.getRect().getMinY();

                Point pointRight = new Point(ballLeft + ballWidth + 1, ballTop);
                Point pointLeft = new Point(ballLeft - 1, ballTop);
                Point pointTop = new Point(ballLeft, ballTop - 1);
                Point pointBottom = new Point(ballLeft, ballTop + ballHeight + 1);

                if (!bricks[i].isDestroyed()) {
                    if (bricks[i].getRect().contains(pointRight)) {
                        ball.setXDir(-1);
                    } else if (bricks[i].getRect().contains(pointLeft)) {
                        ball.setXDir(1);
                    }

                    if (bricks[i].getRect().contains(pointTop)) {
                        ball.setYDir(1);
                    } else if (bricks[i].getRect().contains(pointBottom)) {
                        ball.setYDir(-1);
                    }
                    bricks[i].setDestroyed(true);
                }
            }
        }
    }

/////////////////////////////////////Getters and Setters////////////////////////////////////////////
	
	public int getLayoutFlag() {
		return layoutFlag;
	}

	public void setLayoutFlag(int layoutFlag) {
		this.layoutFlag = layoutFlag;
	}

	public int getCurrentSecond() {
		return currentSecond;
	}

	public void setCurrentSecond(int currentSecond) {
		this.currentSecond = currentSecond;
	}

	public int getCurrentMinute() {
		return currentMinute;
	}

	public void setCurrentMinute(int currentMinute) {
		this.currentMinute = currentMinute;
	}

	public String getTimeForDisplayClock() {
		return timeForDisplayClock;
	}

	public void setTimeForDisplayClock(String timeForDisplayClock) {
		this.timeForDisplayClock = timeForDisplayClock;
	}

	public int getTimerTracker() {
		return timerTracker;
	}

	public void setTimerTracker(int timerTracker) {
		this.timerTracker = timerTracker;
	}

	public int getGameFlag() {
		return gameFlag;
	}

	public void setGameFlag(int gameFlag) {
		this.gameFlag = gameFlag;
	}

	public Ball getBall() {
		return ball;
	}

	public void setBall(Ball ball) {
		this.ball = ball;
	}

	public Paddle getPaddle() {
		return paddle;
	}

	public void setPaddle(Paddle paddle) {
		this.paddle = paddle;
	}

	public Brick[] getBricks() {
		return bricks;
	}

	public void setBricks(Brick[] bricks) {
		this.bricks = bricks;
	}
	
}
