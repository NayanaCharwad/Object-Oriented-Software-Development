package gameEngine;


import gameInit.Boundaries;
import gameInit.Constants;

import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;

/**
 * Paddle class contains coordinates, image, and move instructions for a paddle.
 * 
 * public methods:
 * void move() - Moves paddle according to dx, stored result of user VK_LEFT/RIGHT input.
 * void resetState() - Returns paddle to its initial position.
 * void KeyReleased/KeyPressed(KeyEvent) - sets dx (move behavior) 
 */

public class Paddle extends Dimensions implements Boundaries {
    private String imagePath = "laser-red.png";
    int dx;
    ImageIcon myImageicon;
    
    public Paddle() {
        myImageicon = new ImageIcon(getClass().getClassLoader().getResource(imagePath));
        image = myImageicon.getImage();
        width = image.getWidth(null);
        height = image.getHeight(null);
        resetState();
    }
    

    /*
     * Moves paddle according to dx, stored result of user VK_LEFT/RIGHT input.
     */
    public void move() {
        
    	if (x <= Boundaries.PADDLE_LEFT) {
            x = Boundaries.PADDLE_LEFT;
        }
    	if (x >= Boundaries.PADDLE_RIGHT-width) {
            x = Boundaries.PADDLE_RIGHT-width;
        }
        x += dx;
    }

    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_LEFT) {
            dx = -2;
        }

        if (key == KeyEvent.VK_RIGHT) {
            dx = 2;
        }
    }

    public void keyReleased(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_LEFT) {
            dx = 0;
        }

        if (key == KeyEvent.VK_RIGHT) {
            dx = 0;
        }
    }

    /*
     * Returns paddle to its initial position.
     */
    public void resetState() {
        x = (Constants.WIN_WIDTH / 2) - 30;
        y = 510;
    }
}
