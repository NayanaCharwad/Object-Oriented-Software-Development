package gameEngine;

import java.awt.Image;
import java.awt.Rectangle;

import javax.swing.ImageIcon;

/**
 * Superclass for any rectangular object that is displayed with particular dimensions at particular coordinates in a panel.
 * 
 * public methods:
 * Rectangle getRect() - returns a Rectangle in the position of the game object.
 * void changeImagePath(String) - Switches the 
 */

public class Dimensions {
    public int x;
    public int y;
    public int width;
    public int height;
    ImageIcon myImageIcon;
    public Image image;
    private String imagePath;
    

    public Dimensions() {
    	
    }
    
    /*
     * Returns a Rectangle with dimension of Dimensions object in its coordinates' position.
     */
    public Rectangle getRect() {
        return new Rectangle(x, y,
                image.getWidth(null), image.getHeight(null));
    }
    
    /*
     * Switches game object's image path to given String.
     */
    public void changeImage(String imagePath) {
    	this.imagePath = imagePath;
		this.myImageIcon = new ImageIcon(getClass().getClassLoader().getResource(
				this.imagePath));

		image = myImageIcon.getImage();
    }
    
///////////////////////////////Getters and Setters///////////////////////////////
    
    public void setX(int x) {
        this.x = x;
    }
    
    public void setWidth(int width) {
		this.width = width;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public void setImage(Image image) {
		this.image = image;
	}

	public int getX() {
        return x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getY() {
        return y;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public Image getImage() {
        return image;
    }

   
}
