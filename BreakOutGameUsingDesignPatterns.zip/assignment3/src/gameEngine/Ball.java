package gameEngine;

import gameInit.Boundaries;
import gameInit.Constants;
import gameInterfaces.Savable;

import javax.swing.ImageIcon;

/**
 * Ball class contains coordinates, image, and move instructions for a ball.
 * 
 * public methods:
 * void move() - Updates the ball's coordinates according to game mechanics.
 *
 */

public class Ball extends Dimensions implements Boundaries {
	private int xdir;
	private int ydir;
	private String imagePath = "fire_ball.png";

	public Ball() {
		xdir = 1;
		ydir = -1;

		myImageIcon = new ImageIcon(getClass().getClassLoader().getResource(
				imagePath));

		image = myImageIcon.getImage();

		width = image.getWidth(null);
		height = image.getHeight(null);
		resetState();
	}


	/*
	 * Updates ball's coordinates.
	 */
	public void move() {

		x += xdir;
		y += ydir;

		if (x == 0) {
			setXDir(1);
		}

		if (x == Boundaries.BALL_RIGHT) {
			setXDir(-1);
		}

		if (y == 0) {
			setYDir(1);
		}
	}

	public void resetState() {
		x = Constants.WIN_WIDTH / 2;
		y = 450;
	}
	
///////////////////////////Getters and Setters/////////////////////////////

	public void setXDir(int x) {
		xdir = x;
	}

	public int getXDir() {
		return xdir;
	}

	public void setYDir(int y) {
		ydir = y;
	}

	public int getYDir() {
		return ydir;
	}

}
