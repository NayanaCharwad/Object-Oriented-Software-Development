package gameEngine;

/**
 * Brick class contains coordinates, image, and move instructions for a brick.
 * 
 * public methods:
 * None of interest. Turns out that bricks don't do much.
 */


import gameInit.Boundaries;

import javax.swing.ImageIcon;




public class Brick extends Dimensions implements Boundaries {

    private String imagePath = "blue.png";
    boolean destroyed;

    public Brick(int x, int y) {
        this.x = x;
        this.y = y;

        myImageIcon = new ImageIcon(getClass().getClassLoader().getResource(imagePath));
        image = myImageIcon.getImage();
        width = image.getWidth(null);
        height = image.getHeight(null);

        destroyed = false;
    }
    

    
///////////////////////////////////Getters and Setters//////////////////////////////////////
    
    public boolean isDestroyed() {
        return destroyed;
    }

    public void setDestroyed(boolean destroyed) {
        this.destroyed = destroyed;
    }

}
