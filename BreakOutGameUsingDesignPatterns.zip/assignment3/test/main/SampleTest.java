package main;

import org.junit.Assert;
import org.junit.Test;

public class SampleTest extends Assert {
	@Test
    public void testSuccess() {
        assertTrue(true);
    }
}
