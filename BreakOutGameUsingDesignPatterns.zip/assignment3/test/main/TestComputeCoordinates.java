package main;

import java.util.ArrayList;

import gameEngine.Ball;
import gameEngine.Brick;
import gameEngine.ComputeCoordinates;
import gameEngine.Paddle;
import gameEngine.StoreDimensions;
import gameInit.Constants;

import org.junit.Assert;
import org.junit.Test;

public class TestComputeCoordinates extends Assert implements Constants {

	private Brick[] bricks;
	private ComputeCoordinates computeCoordinates;
	private Ball testBall;
	private Paddle testPaddle;
	private ComputeCoordinates testObjComputeCoordinates;
	private int timerTracker;
    private String timeForDisplayClock;
    private StoreDimensions testObjStoreDimensions;
	
	public TestComputeCoordinates(){
		bricks = new Brick[Constants.TOTAL_BRICKS];
		computeCoordinates = new ComputeCoordinates();
		testBall = new Ball();
		testPaddle = new Paddle();
		testObjComputeCoordinates = new ComputeCoordinates();
		timerTracker = 100;
		testObjStoreDimensions = new StoreDimensions(120,231, 500, 800, 2, "00:02", getBrickFlags(), 1);
	}
	
	public Ball getTestBall() {
		return testBall;
	}

	public void setTestBall(Ball testBall) {
		this.testBall = testBall;
	}

	public Paddle getTestPaddle() {
		return testPaddle;
	}

	public void setTestPaddle(Paddle testPaddle) {
		this.testPaddle = testPaddle;
	}

	public ComputeCoordinates getTestObjComputeCoordinates() {
		return testObjComputeCoordinates;
	}

	public void setTestObjComputeCoordinates(
			ComputeCoordinates testObjComputeCoordinates) {
		this.testObjComputeCoordinates = testObjComputeCoordinates;
	}

	public int getTimerTracker() {
		return timerTracker;
	}


	public void setTimerTracker(int timerTracker) {
		this.timerTracker = timerTracker;
	}

	public String getTimeForDisplayClock() {
		return timeForDisplayClock;
	}

	public void setTimeForDisplayClock(String timeForDisplayClock) {
		this.timeForDisplayClock = timeForDisplayClock;
	}

	public StoreDimensions getTestObjStoreDimensions() {
		return testObjStoreDimensions;
	}

	public void setTestObjStoreDimensions(StoreDimensions testObjStoreDimensions) {
		this.testObjStoreDimensions = testObjStoreDimensions;
	}

	public ComputeCoordinates getComputeCoordinates() {
		return computeCoordinates;
	}

	public void setComputeCoordinates(ComputeCoordinates computeCoordinates) {
		this.computeCoordinates = computeCoordinates;
	}

	public Brick[] getBricks() {
		return bricks;
	}
	
	public void setBricks(Brick[] bricks) {
		this.bricks = bricks;
	}

	public ArrayList<Boolean> getBrickFlags() {
		ArrayList<Boolean> brickFlags = new ArrayList<Boolean>();
		for (int i = 0, k= 0; i < Constants.BRICK_ROWS  ; i++) {
		       for (int j = 0; j < Constants.BRICK_COLUMNS; j++) {
		            bricks[k] = new Brick(j * 70 + 120, i * 20 + 100);
		            k++;
		            }
		       }
		for (int i=0;i<TOTAL_BRICKS;i++){
			brickFlags.add(i,this.bricks[i].isDestroyed());}
		return brickFlags;
		}
	
	@Test
	public void testGameData() {
		if(testObjStoreDimensions.getBallX()== 119 && testObjStoreDimensions.getBallY()==231 && testObjStoreDimensions.getPaddleX() == 500 && 
				testObjStoreDimensions.getPaddleY() == 800 && testObjStoreDimensions.getGameFlag() ==2 &&  (testObjStoreDimensions.getIsBrickDestroyed()).containsAll(getBrickFlags()) && testObjStoreDimensions.getLayoutFlag() == 1 );
		assertTrue(true);	
	}
	
	public ArrayList<Object> simulategetUndoObjects() {
		ArrayList<Object> listObjects = new ArrayList<Object>();
		listObjects.add(2);
		listObjects.add("00:03");
		return listObjects;
	}
	
	@Test  
	public void testgetUndoObjects() {
		ArrayList<Object> listObjects = simulategetUndoObjects();
		if(((Integer)listObjects.get(0) == 2 ) && ((String) listObjects.get(1)== "00:03"));
			assertTrue(true);	
	}
	
	public void saveDimensions(StoreDimensions testObjStoreDimensions) {	
		getTestBall().setX(getTestObjStoreDimensions().getBallX());
		getTestBall().setY(getTestObjStoreDimensions().getBallY());
		getTestPaddle().setY(getTestObjStoreDimensions().getPaddleY());
		getTestBall().setX(getTestObjStoreDimensions().getPaddleX());
		getTestObjComputeCoordinates().setGameFlag(getTestObjStoreDimensions().getGameFlag());
		getTestObjComputeCoordinates().setTimeForDisplayClock(getTestObjStoreDimensions().getSetTimeForDisplayClock());
		ArrayList<Boolean> getBrickFlags = testObjStoreDimensions.getIsBrickDestroyed();
		getTestObjComputeCoordinates().setLayoutFlag(this.getTestObjStoreDimensions().getLayoutFlag());
		for (int i=0;i<TOTAL_BRICKS;i++){
			this.bricks[i].setDestroyed(getBrickFlags.get(i));
		}
	}
	
	@Test
	public void testSaveDimensions() {
		if(getTestBall().getX()== 120 && getTestBall().getY()==231 && getTestPaddle().getY() == 500 && 
				getTestPaddle().getY() == 800 && getTestObjComputeCoordinates().getGameFlag() ==2 &&  (getTestObjStoreDimensions().getIsBrickDestroyed()).containsAll(getBrickFlags()) && this.getTestObjStoreDimensions().getLayoutFlag() == 1 );
		assertTrue(true);	
	}
	
	public String simulateUpdateClock() {	
		int currentSecond = 05;
		int currentMinute = 01;
		timerTracker++;
		if (timerTracker >= 100) {
			if (currentSecond == 60) {
				testObjComputeCoordinates.refresh();
			}
			currentSecond++;
			timeForDisplayClock = String.format("%02d:%02d", currentMinute,currentSecond);
			timerTracker = 0;
		}
		return timeForDisplayClock;
	}
	
	@Test
	public void testUpdateClock() {
		String time = simulateUpdateClock();
		if(time == "01:06")
			assertTrue(true);	
	}
}
