package controller;

//implementation of command pattern 
public interface Command {
	
	public void execute();
	
}